A fake working directory for setlocalversion to execute on.
